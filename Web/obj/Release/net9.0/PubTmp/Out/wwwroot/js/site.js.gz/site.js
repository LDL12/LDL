﻿//校验数据是否有效
function IsValidData(data)
{
    return data !== undefined && data !== null && data !== '';
}
